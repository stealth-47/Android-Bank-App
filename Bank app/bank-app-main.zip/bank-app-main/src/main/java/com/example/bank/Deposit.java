package com.example.bank;

public class Deposit {
    Account ac= new Account();
    MainActivity dpt = new MainActivity();
    int godfrey= dpt.deposit();


}
